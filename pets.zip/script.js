

let nameInput = document.querySelector('.name');

const addi = "url('https://sandbox-uploads.imgix.net/u/1586453818-f348f7ea08764dce497f96549f203e40?w=600')";
const coco = "url('https://sandbox-uploads.imgix.net/u/1586453944-81c156bc7a4e8088f654174611b6ec10?w=600')";
const milagros = "url('https://sandbox-uploads.imgix.net/u/1586454167-f701fdcde7f386e55be60dfdf266516a?w=600')";
const mini = "url('https://sandbox-uploads.imgix.net/u/1586454489-e87d587a28853e1c9552f1e00f71df78?w=600')";
const ale = "url('https://sandbox-uploads.imgix.net/u/1586457790-fb1ed9cda0544557a4aefa65ac3f5073?w=600')";
const michu = "url('https://sandbox-uploads.imgix.net/u/1586457852-2d7d0c004ae2cf6131c49cbe6939be91?w=600')";
const filo = "url('https://sandbox-uploads.imgix.net/u/1586457929-976337bf2e5b0e24fb93b1768f78b788?w=600')";
const rocky = "url('https://sandbox-uploads.imgix.net/u/1586458003-0d93d2821c27dacc22fe282f6df80589?w=600')";
const paris = "url('https://sandbox-uploads.imgix.net/u/1586458115-f98f5106ecc0382c2efa5c7a293700d8?w=600')";



const dictionary = {
	"addi": addi,
	"coco" : coco,
	"milagros" : milagros,
	"mini" : mini,
	"ale" : ale,
	"michu" : michu,
	"filo" : filo,
	"rocky" : rocky,
	"paris" : paris,
  "alemania": ale,
 }

//get the name of the dog in the input 
function getDogName(){
  	return nameInput.value.toLowerCase();
}
//select the dog name input in the textbox
function buttonClicked(){
  //get dog's name
  const currentDogName = getDogName()

  	// get image url
	const img = dictionary[currentDogName];
 
  
	// check input
	if (!img) return alert("Doesn't exist"); 

	// set image
	document.body.style.backgroundImage = img;

   //clear the input
   nameInput.value = ""

  document.getElementById('message').innerHTML= "This is " + currentDogName.charAt(0).toUpperCase() + currentDogName.slice(1)

}
	
// Execute a function when the user releases a key on the keyboard
nameInput.addEventListener("keyup", function(event) {
  // Number 13 is the "Enter" key on the keyboard
  if (event.keyCode === 13) {
   buttonClicked();
  }
});

	/*let fondo = document.body.style;

	switch (getDogName()) {
		case "addi":
			fondo.backgroundImage = addi;
			break;
		case "coco":
			fondo = coco;
			break;
		case "milagros":
			fondo = milagros;
			break;
		case "mini":
			fondo = mini;
			break;
		case "ale":
			fondo = ale;
			break;
		case "michu":
   		fondo = michu;
			break;
		case "filo":
			fondo = filo;
			break;
		case "rocky":
			fondo = rocky;
			break;
		case "paris":
			fondo = paris;
			break;
	}*/







