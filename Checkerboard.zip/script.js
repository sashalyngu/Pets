// grab the silders
let width_slider = document.getElementById('width-slider');
let height_slider = document.getElementById('height-slider');

// grab the spans that display the numbers
let width_num = document.getElementById("width-num");
let height_num = document.getElementById("height-num");

// grab the table
let table = document.getElementById('board');
generateBoard()

function getColor(x, y){
	if ((x + y) % 2 === 0){
		return "black";
	}
	else {
		return "white";
	}
}

function generateBoard(){
	// clear previous board
	while (table.hasChildNodes()) { //returns a boolean 
        table.removeChild(table.lastChild);
    }

	// get board size
	const BOARD_HEIGHT = height_slider.value;
	const BOARD_WIDTH = width_slider.value;

	// create rows
	for (let y=0; y < BOARD_HEIGHT; y++){
		let newTR = document.createElement("tr");

		// create cells
		for (let x=0; x < BOARD_WIDTH; x++){
			let newTD = document.createElement("td");

			newTD.bgColor = getColor(x, y);
			//newTD.innerText = x + ", " + y;

			newTR.appendChild(newTD);
		}

		table.appendChild(newTR);
	}
}


width_slider.onchange = function(){
	width_num.innerText = width_slider.value;
  generateBoard()
};

height_slider.onchange = function(){
	height_num.innerText = height_slider.value;
  generateBoard()
};




